// 2. Write a Java program to store city names and their STD codes using an appropriate 
// collection and perform following operations:
// i. Add a new city and its code (No duplicates) 
// ii. Remove a city from the collection 
// iii. Search for a city name and display the code

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Q2 {
    public static void main(String[] args) {
        
        Map<String, String> city = new HashMap<>();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\nSelect an operation:");
            System.out.println("1. Add a new city and its code");
            System.out.println("2. Remove a city");
            System.out.println("3. Search for a city and display its code");
            System.out.println("4. Exit");
            System.out.println("Enter choice: ");

            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter city name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter STD code: ");
                    String code = sc.nextLine();
                    if (!city.containsKey(name)) {
                        city.put(name, code);
                        System.out.println("City added successfully.");
                    } else {
                        System.out.println("City already exists. Cannot add duplicate.");
                    }
                    break;
                case 2:
                    System.out.print("Enter city name to remove: ");
                    String remove = sc.nextLine();
                    if (city.containsKey(remove)) {
                        city.remove(remove);
                        System.out.println("City removed successfully.");
                    } else {
                        System.out.println("City not found in the collection.");
                    }
                    break;
                case 3:
                    System.out.print("\nEnter city name to search: ");
                    String search = sc.nextLine();
                    if (city.containsKey(search)) {
                        System.out.println("STD code for " + search + " is: " + city.get(search));
                    } else {
                        System.out.println("City not found in the collection.");
                    }
                    break;
                case 4:
                    System.out.println("Exiting program...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
            sc.close();
        }
    }
}
