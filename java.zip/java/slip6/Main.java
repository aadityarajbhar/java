// . Write a java program to simulate traffic signal using threads

class TrafficSignal {
    private String currentSignal;

    public TrafficSignal() {
        currentSignal = "RED";
    }

    public synchronized void changeSignal() {
        if (currentSignal.equals("RED")) {
            currentSignal = "GREEN";
        } else if (currentSignal.equals("GREEN")) {
            currentSignal = "YELLOW";
        } else if (currentSignal.equals("YELLOW")) {
            currentSignal = "RED";
        }
        System.out.println("Signal changed to: " + currentSignal);
    }

    public String getCurrentSignal() {
        return currentSignal;
    }
}

class TrafficController extends Thread {
    private TrafficSignal signal;

    public TrafficController(TrafficSignal signal) {
        this.signal = signal;
    }

    public void run() {
        for(int i=0;i<10;i++) {
            signal.changeSignal();
            try {
                Thread.sleep(2000); // Simulate time for each signal state
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        TrafficSignal signal = new TrafficSignal();
        TrafficController controller = new TrafficController(signal);
        controller.start();

        // Print current signal every second
        for(int i=0;i<10;i++) {
            System.out.println("Current Signal: " + signal.getCurrentSignal());
            try {
                Thread.sleep(1000); // Simulate time between signal checks
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
